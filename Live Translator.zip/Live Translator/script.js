document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('inputText').addEventListener('input', translateText);
    document.getElementById('targetLanguage').addEventListener('change', translateText);

    // Fetch available languages on page load
    fetchLanguages();
});

async function fetchLanguages() {
    const url = 'https://microsoft-translator-text.p.rapidapi.com/languages?api-version=3.0';
    const options = {
        method: 'GET',
        headers: {
            'x-rapidapi-key': 'a5f59437f3msh8b708a8da424c00p193090jsna4fa6397966d',
            'x-rapidapi-host': 'microsoft-translator-text.p.rapidapi.com'
        }
    };

    try {
        const response = await fetch(url, options);
        if (response.ok) {
            const result = await response.json();
            console.log(result);
        } else {
            console.error('Error:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

async function translateText() {
    const inputText = document.getElementById('inputText').value;
    const targetLanguage = document.getElementById('targetLanguage').value;

    const apiKey = 'a5f59437f3msh8b708a8da424c00p193090jsna4fa6397966d';
    const url = 'https://google-translate1.p.rapidapi.com/language/translate/v2';

    const data = {
        q: inputText,
        target: targetLanguage
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-RapidAPI-Key': 'a5f59437f3msh8b708a8da424c00p193090jsna4fa6397966d',
                'X-RapidAPI-Host': 'google-translate1.p.rapidapi.com'
            },
            body: new URLSearchParams(data)
        });

        if (response.ok) {
            const jsonResponse = await response.json();
            const translatedText = jsonResponse.data.translations[0].translatedText;
            document.getElementById('translatedText').innerText = translatedText;
        } else {
            console.error('Error in translation:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Error in translation:', error);
    }
}

// New function to send translation example
async function sendTranslationExample() {
    const url = 'https://microsoft-translator-text-api3.p.rapidapi.com/examples?to=es&from=en';
    const options = {
        method: 'POST',
        headers: {
            'x-rapidapi-key': 'a5f59437f3msh8b708a8da424c00p193090jsna4fa6397966d',
            'x-rapidapi-host': 'microsoft-translator-text-api3.p.rapidapi.com',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify([
            {
                Text: 'fly',
                Translation: 'volar'
            }
        ])
    };

    try {
        const response = await fetch(url, options);
        if (response.ok) {
            const result = await response.json();
            console.log(result);
        } else {
            console.error('Error:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

// Call sendTranslationExample on page load or based on an event
sendTranslationExample();
